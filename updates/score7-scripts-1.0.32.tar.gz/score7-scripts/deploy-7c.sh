#!/bin/bash
echo "This Score 7 Field Kit deployment has been revoked."
exit 78
